var classhit =
[
    [ "hit", "classhit.html#a28033534baf49ea09fecf630e0bc9eb5", null ],
    [ "get_player_id", "classhit.html#a914b4442560954de4de27f85f6168919", null ],
    [ "get_weapon_id", "classhit.html#afba4878708b2c56bddf39cfb90c1a4d9", null ]
];