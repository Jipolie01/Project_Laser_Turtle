var classmy__player__information =
[
    [ "my_player_information", "classmy__player__information.html#a32ffeb6d9e2850542685e4fb40e28f9a", null ],
    [ "get_compiled_bits", "classmy__player__information.html#a065c0e06903f41d5ecfcadbf7bd0bb12", null ],
    [ "get_health", "classmy__player__information.html#a627d9bfc027e556998519c7ff9eff157", null ],
    [ "set_compiled_bits", "classmy__player__information.html#a0cbbe520cb8591e71f1ac4164c9536d2", null ],
    [ "set_health", "classmy__player__information.html#ae7c84c2a5a688d61f9452c78d6e8e82e", null ]
];