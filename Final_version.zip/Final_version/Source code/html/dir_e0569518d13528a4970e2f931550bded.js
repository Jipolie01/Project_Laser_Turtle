var dir_e0569518d13528a4970e2f931550bded =
[
    [ "send_ir_classes.hpp", "ir_01sender_01with_01channel_2send__ir__classes_8hpp.html", [
      [ "ir_sender", "classir__sender.html", "classir__sender" ],
      [ "send_controller", "classsend__controller.html", "classsend__controller" ]
    ] ]
];