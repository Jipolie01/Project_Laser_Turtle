var structsound__lookup =
[
    [ "amount", "structsound__lookup.html#ab6b83a017a9d6a4e28628c20f63ad473", null ],
    [ "amount_wait", "structsound__lookup.html#a8bcf50a31f32ff0081133edc380bb0a1", null ],
    [ "duration", "structsound__lookup.html#a7a155cf327d9ef451c1e9b04f940a12b", null ],
    [ "frequency", "structsound__lookup.html#a3f597ffbf84891f44319e621db98ef81", null ]
];