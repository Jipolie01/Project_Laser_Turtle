var init__game_8hpp =
[
    [ "init_game_controller", "classinit__game__controller.html", "classinit__game__controller" ],
    [ "INIT_GAME_HPP", "init__game_8hpp.html#a73c23bdabd06b6d96d3f8435c7395e67", null ]
];