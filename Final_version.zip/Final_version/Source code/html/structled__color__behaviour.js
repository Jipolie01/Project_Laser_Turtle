var structled__color__behaviour =
[
    [ "blue", "structled__color__behaviour.html#acae43a677eaddda748c5bfd3a5caa75b", null ],
    [ "green", "structled__color__behaviour.html#a35e719a7d391ab42db18595348acbdd5", null ],
    [ "red", "structled__color__behaviour.html#a7b361774f3548f07e087525c2a78fe78", null ]
];