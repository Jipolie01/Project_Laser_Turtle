var classgame__time__controller =
[
    [ "game_time_controller", "classgame__time__controller.html#ad2a906f75a90ca5c906aeb8093ac579b", null ],
    [ "enable_start_flag", "classgame__time__controller.html#a33a1f1c002465109b1caacedbf1a820f", null ],
    [ "set_time", "classgame__time__controller.html#a01ace9e573244e15cd28c074792b52f6", null ]
];