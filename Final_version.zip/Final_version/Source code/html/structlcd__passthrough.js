var structlcd__passthrough =
[
    [ "assignment", "structlcd__passthrough.html#a74c4254fef0e0e422ac0e078d7824c3a", null ],
    [ "game_begin", "structlcd__passthrough.html#a423c70d93fcc677406a38a5e7b70e874", null ],
    [ "game_end", "structlcd__passthrough.html#a522dee420466fc4cf7c873e0db5dfccb", null ],
    [ "line1", "structlcd__passthrough.html#a33de361ffdcc3a003b317df1c7f4e931", null ],
    [ "line2", "structlcd__passthrough.html#a168d61fecb6e46fc814a004f28f7e64f", null ],
    [ "line3", "structlcd__passthrough.html#afaab03e889a8417894e5e23268969276", null ],
    [ "line4", "structlcd__passthrough.html#a17db87a86d7232445024e336abefe4f9", null ],
    [ "line5", "structlcd__passthrough.html#a79943b73fa79c1ca25b39fa1538d6cf6", null ],
    [ "line6", "structlcd__passthrough.html#a03b23e976dba9d2e5f83ed059e56b332", null ],
    [ "line7", "structlcd__passthrough.html#ac7d27a96a3b6c25ebc2a2539ec631e81", null ],
    [ "line8", "structlcd__passthrough.html#a753b84809de13c39b85b2a569211eaa2", null ],
    [ "player_hit", "structlcd__passthrough.html#aebb53028202d32c5b94643f7ca138609", null ]
];