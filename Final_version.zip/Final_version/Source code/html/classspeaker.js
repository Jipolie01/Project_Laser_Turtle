var classspeaker =
[
    [ "speaker", "classspeaker.html#a3c4dcbdc5d9cc99e1fa6c30dea0235c3", null ],
    [ "play", "classspeaker.html#a625c84e34f9ee40a7baeb2d6baa816a1", null ]
];