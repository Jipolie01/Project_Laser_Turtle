var ir__receiver__classes_8hpp =
[
    [ "ir_receiver_controller", "classir__receiver__controller.html", "classir__receiver__controller" ],
    [ "IR_RECEIVER_CLASSES_HPP", "ir__receiver__classes_8hpp.html#a032ae1b388975120c4a2ca1555863cce", null ]
];