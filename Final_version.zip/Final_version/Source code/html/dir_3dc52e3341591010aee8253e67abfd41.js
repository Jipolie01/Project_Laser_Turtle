var dir_3dc52e3341591010aee8253e67abfd41 =
[
    [ "send_ir_classes.hpp", "ir_01sender_01with_01flag_2send__ir__classes_8hpp.html", [
      [ "ir_sender", "classir__sender.html", "classir__sender" ],
      [ "send_controller", "classsend__controller.html", "classsend__controller" ]
    ] ]
];