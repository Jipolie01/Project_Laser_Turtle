var classir__message__logic =
[
    [ "ir_message_logic", "classir__message__logic.html#af65240d9b8999fd1b956fc2da17a6d3e", null ],
    [ "decode", "classir__message__logic.html#aab003c06594ef0dd7caf33d0c928b11b", null ],
    [ "encode", "classir__message__logic.html#a60cf2eae7b2ff8285440068b6419863c", null ]
];