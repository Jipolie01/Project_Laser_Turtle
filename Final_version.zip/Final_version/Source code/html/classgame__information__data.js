var classgame__information__data =
[
    [ "game_information_data", "classgame__information__data.html#adf5e84fd74e3e18b71b4acdc74de6844", null ],
    [ "get_cooldown_time", "classgame__information__data.html#a534bcb8f2bec244ec6ab3eb200f4e301", null ],
    [ "get_game_has_start", "classgame__information__data.html#a513ec296585aedfedfd917528f9f8fe6", null ],
    [ "get_game_time", "classgame__information__data.html#ad63a9f9e72242aa68cef64d53ce52249", null ],
    [ "set_cooldown_time", "classgame__information__data.html#ab690a619ee210b5660017d8a57ed630a", null ],
    [ "set_game_has_start", "classgame__information__data.html#a4dbb7c0d6ba269942ba417c800c66c11", null ],
    [ "set_game_time", "classgame__information__data.html#a641a08d61da5a638cb7fe78b9c71cb11", null ]
];