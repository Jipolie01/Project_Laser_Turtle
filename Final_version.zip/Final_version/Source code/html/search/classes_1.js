var searchData=
[
  ['game_5finformation_5fdata',['game_information_data',['../classgame__information__data.html',1,'']]],
  ['game_5ftime_5fcontroller',['game_time_controller',['../classgame__time__controller.html',1,'']]]
];
