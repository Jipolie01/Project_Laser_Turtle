var searchData=
[
  ['hit',['hit',['../classspeaker__controller.html#a188de8c71de428765cd73f0f66d6d44e',1,'speaker_controller']]]
];
