var classsend__controller =
[
    [ "send_controller", "classsend__controller.html#a31abdb529dba4bde0893bf04d0ef113d", null ],
    [ "send_controller", "classsend__controller.html#a4f7f3b8afe7b94c3b6f284ad31fb4492", null ],
    [ "enable_flag", "classsend__controller.html#a29cfa70656efe2e26bc2c7cebe84ee46", null ],
    [ "write", "classsend__controller.html#ada7d206636bf7b867696cfa8fdd080b2", null ]
];