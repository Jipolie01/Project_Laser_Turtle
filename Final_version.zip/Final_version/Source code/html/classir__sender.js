var classir__sender =
[
    [ "send_message", "classir__sender.html#a6b23d2e93be4f000ca689395613ea487", null ],
    [ "send_message", "classir__sender.html#a6b23d2e93be4f000ca689395613ea487", null ],
    [ "send_one", "classir__sender.html#a53efa5b083ddbbc9f8de912a44135e08", null ],
    [ "send_one", "classir__sender.html#a53efa5b083ddbbc9f8de912a44135e08", null ],
    [ "send_zero", "classir__sender.html#a3868a2512035b0f6b5b6df093db22fbb", null ],
    [ "send_zero", "classir__sender.html#a3868a2512035b0f6b5b6df093db22fbb", null ],
    [ "set_zero", "classir__sender.html#aa38f450682d96d47347dceefb7167976", null ],
    [ "set_zero", "classir__sender.html#aa38f450682d96d47347dceefb7167976", null ]
];