var classregister__game__parameters__controller =
[
    [ "register_game_parameters_controller", "classregister__game__parameters__controller.html#a291e306ca9e214208d0145058af13eeb", null ],
    [ "setup", "classregister__game__parameters__controller.html#a9599db32b65bd0839ae4037acfdadd95", null ]
];