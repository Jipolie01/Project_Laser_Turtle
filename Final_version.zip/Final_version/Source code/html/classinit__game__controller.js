var classinit__game__controller =
[
    [ "init_game_controller", "classinit__game__controller.html#a8b506bc4f98428bbceca83027a41f184", null ]
];